﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace My_Library.Enums
{
    public enum Genre
    {
        Comedy,
        Horror,
        Action,
        Drama,
        SciFi

    }
}
